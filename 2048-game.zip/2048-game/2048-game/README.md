# 2048 Game

## Powered by Angular

* Demo: https://2048.novyk.org
* Stream of creating: https://www.youtube.com/watch?v=MiWPjFt8GEQ

## ToDo

- [ ] refactor actions
- [ ] split to components
- [ ] handle fast change animation
- [ ] calc & display earned points
- [ ] "new game" button
- [ ] fix game over
- [ ] AOT build
