import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { FieldModule } from './field/field.module';
import { FieldComponent } from './field/field/field.component';
import {MaterialModule} from './material.module';
@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    BrowserAnimationsModule,
    FieldModule,
    MaterialModule,
    RouterModule.forRoot([
      {
        path: '',
        component: FieldComponent,
      },
    ]),
  ],
  declarations: [
    AppComponent,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
],
  bootstrap: [AppComponent],
})
export class AppModule {
}
